import java.util.Random;
import java.util.Scanner;

public class Main {
    //3 Пользователь вводит два числа.
    // Если они не равны, то вывести в консоль их сумму, иначе вывести их произведение. Используйте тернарный оператор.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("введите 2 числа");
        int num = scn.nextInt();
        int num2 = scn.nextInt();
        if (num != num2) {
            System.out.println("Сумма двух чисел" + (num + num2));
        } else {
            System.out.println(num * num2);
        }
        // С помощью Random сгенерируйте три числа.
        // Напишите программу, которая находит максимальное из них. Используйте тернарные операторы.

        System.out.println("ZADANIE 2");
        Random rm = new Random();
        int x1 = rm.nextInt();
        int x2 = rm.nextInt();
        int x3 = rm.nextInt();
        System.out.println(" X1 " + x1 + " x2 " + x2 + " x3 "+ x3);
        if (x1 >= x2 && x1 >= x3) {
            System.out.println(x1);
        }
        if (x2 >= x1 && x2 >= x3) {
            System.out.println(x2);
        }
        if (x3 >= x2 && x3 >= x1) {
            System.out.println(x3);
        }


    }
}