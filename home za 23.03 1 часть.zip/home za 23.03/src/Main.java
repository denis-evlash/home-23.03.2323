import java.util.Scanner;

public class Main {
    //умножить число на 2, если оно нечётное;
    //
    //прибавить к числу 5, если если оно заканчивается на 5 или 0.
    //Если число < 0, то взять его по модулю и разделить на 3.
    //Результат вычисления вывести в консоль.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите число");
        int number = scn.nextInt();
        if (number > 0 && number % 2 != 0){
            System.out.println(number *2);
        }
        if ( (number % 10 == 5 || number % 10 == 0) && number > 0){
            System.out.println(number + 5);
        }
        if (number < 0) {
            System.out.println(Math.abs(number) / 3);
        }


    }
}