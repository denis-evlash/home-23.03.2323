public enum snake {
    MARS, SNIKERS, TWIX, KITKAT

}
