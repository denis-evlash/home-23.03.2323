import java.util.Scanner;

public class Main {
    //Создайте перечисление для угощений в снек-автомате (3-4 позиции).
    //Пользователь вводит номер снека. Программа должна вывести название снека, который выдал автомат.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите номер Сладости: ");
        int numberSnace = scn.nextInt();
        if (numberSnace == 1 ){
            System.out.println(snake.MARS);
        }if (numberSnace == 2 ){
            System.out.println(snake.SNIKERS);
        }if (numberSnace == 3 ){
            System.out.println(snake.TWIX);
        }if (numberSnace == 4 ){
            System.out.println(snake.KITKAT);

        }




    }
}